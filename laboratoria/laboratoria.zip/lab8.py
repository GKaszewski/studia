l = []
for i in range(10):
    liczba = int(input('podaj liczbe: '))
    l.append(liczba)
print(l)