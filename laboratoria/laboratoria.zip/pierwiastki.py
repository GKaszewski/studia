from math import sqrt
sqrts = [sqrt(x) for x in range(1, 51)]
print(sqrts)