from collections import Counter
string = input("Podaj napis: ")

print(f'Wystapienia litery "a": {string.lower().count("a")}')
print(f'Wystapienia litery "a": {Counter(string.lower())["a"]}')
